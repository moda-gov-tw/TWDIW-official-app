/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.example.did_sdk_module;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "com.example.did_sdk_module";
  public static final String BUILD_TYPE = "debug";
}
